# Wireshark Summary (Optional)

If Wireshark was used:
- Capture filters: `tcp port 80` to isolate HTTP traffic
- Observed SYN packets during scan
- Confirmed Nmap's stealth (SYN) scan behavior visually

No PII or sensitive data captured.
